#h3 relax
relax_lag_fp1 <- list()
relax_dim_fp1 <- list()
for (i in 1:40) {
  file_path <- paste0("C:/Users/giuli/Downloads/archive/Relax-20231211T181913Z-001/Relax/Relax_sub_", i, ".csv")
  f <- read.csv(file_path)
  relax_fp1 <- f[, "X2"]
  
  #extract the avarage delay
  tau1.ami <- timeLag(relax_fp1, technique = "ami", lag.max = 350, do.plot = T)
  relax_lag_fp1 <- append(relax_lag_fp1, tau1.ami)
  
  #extract the amount of dims
  emb.dim = estimateEmbeddingDim(relax_fp1, time.lag = tau1.ami, max.embedding.dim = 25)
  relax_dim_fp1 <- append(relax_dim_fp1, emb.dim)
}

mean_relax_lag_fp1 <- mean(unlist(relax_lag_fp1))
mean_relax_lag_fp1_rounded <- round(mean_relax_lag_fp1)
print(mean_relax_lag_fp1_rounded)

mean_relax_dim_fp1 <- mean(unlist(relax_dim_fp1))
mean_relax_dim_fp1_rounded <- round(mean_relax_dim_fp1)
print(mean_relax_dim_fp1_rounded)


stroop_lag_fp1 <- list()
stroop_dim_fp1 <- list()
for (i in 1:40) {
  file_path1 <- paste0("C:/Users/giuli/Downloads/archive/Stroop-20231211T181911Z-001/Stroop/Stroop_sub_", i, ".csv")
  f1 <- read.csv(file_path1)
  stroop_fp1 <- f1[, "X2"]
  
  #extract the avarage delay
  tau1.ami <- timeLag(stroop_fp1, technique = "ami", lag.max = 350, do.plot = T)
  stroop_lag_fp1 <- append(stroop_lag_fp1, tau1.ami)
  
  #extract the amount of dims
  emb.dim = estimateEmbeddingDim(stroop_fp1, time.lag = tau1.ami, max.embedding.dim = 25)
  stroop_dim_fp1 <- append(stroop_dim_fp1, emb.dim)
}

mean_stroop_lag_fp1 <- mean(unlist(stroop_lag_fp1))
mean_stroop_lag_fp1_rounded <- round(mean_stroop_lag_fp1)
print(mean_stroop_lag_fp1_rounded)

mean_stroop_dim_fp1 <- mean(unlist(stroop_dim_fp1))
mean_stroop_dim_fp1_rounded <- round(mean_stroop_dim_fp1)
print(mean_stroop_dim_fp1_rounded)