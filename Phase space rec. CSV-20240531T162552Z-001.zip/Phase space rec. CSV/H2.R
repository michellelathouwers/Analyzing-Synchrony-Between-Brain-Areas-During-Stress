#packages
require(nonlinearTseries)
require(crqa)
require(casnet)
require(tseriesChaos)
require(plot3D)
require(scatterplot3d)
require(rgl)
require(ggplot2)
require(Hmisc)
options(scipen=999)

#preprocessing steps:
#load data
all_averages_h2 <- list()
averages_str_h2 <- list()
averages_rel_h2 <- list()

#loop for values hypothesis 1

for (i in 1:40) {
  file_path1 <- paste0("C:/Users/giuli/Downloads/archive/Stroop-20231211T181911Z-001/Stroop/Stroop_sub_", i, ".csv")
  f1 <- read.csv(file_path1)
  stroop_fp1 <- f1[, "X2"]
  stroop_f7 <- f1[, "X3"]
  file_path2 <- paste0("C:/Users/giuli/Downloads/archive/Relax-20231211T181913Z-001/Relax/Relax_sub_", i, ".csv")
  f2 <- read.csv(file_path2)
  relax_fp1 <- f2[, "X2"]
  relax_f7 <- f2[, "X3"]
  
  tau1Str.ami <- timeLag(stroop_fp1, technique = "ami", lag.max = 350, do.plot = T)
  tau1Rel.ami <- timeLag(relax_fp1, technique = "ami", lag.max = 350, do.plot = T)
  
  tau2Str.ami <- timeLag(stroop_f7, technique = "ami", lag.max = 350, do.plot = T)
  tau2Rel.ami <- timeLag(relax_f7, technique = "ami", lag.max = 350, do.plot = T)
  
  Avg_lag_str <- mean(c(tau1Str.ami, tau2Str.ami))
  Avg_lag_rel <- mean(c(tau1Rel.ami, tau2Rel.ami))
  
  emb1Str.dim <- estimateEmbeddingDim(stroop_fp1, time.lag = tau1Str.ami, max.embedding.dim = 25)
  emb1Rel.dim <- estimateEmbeddingDim(relax_fp1, time.lag = tau1Rel.ami, max.embedding.dim = 25)
  
  emb2Str.dim <- estimateEmbeddingDim(stroop_f7, time.lag = tau2Str.ami, max.embedding.dim = 25)
  emb2Rel.dim <- estimateEmbeddingDim(relax_f7, time.lag = tau2Rel.ami, max.embedding.dim = 25)
  
  Avg_dim_str <- mean(c(emb1Str.dim, emb2Str.dim))
  Avg_dim_rel <- mean(c(emb1Rel.dim, emb2Rel.dim))
  
  data_str <- data.frame(Lag = Avg_lag_str, Dimension = Avg_dim_str)
  data_rel <- data.frame(Lag = Avg_lag_rel, Dimension = Avg_dim_rel)
  
  averages_str_h1[[i]] <- data_str
  averages_rel_h1[[i]] <- data_rel
}

averages_str_df <- do.call(rbind, averages_str_h2)
averages_rel_df <- do.call(rbind, averages_rel_h2)

write.csv(averages_str_df, "C:/Users/giuli/OneDrive/Documenten/Uni/M Jaar 1/Sem2/ComS/averages_str_h2.csv", row.names = FALSE)
write.csv(averages_rel_df, "C:/Users/giuli/OneDrive/Documenten/Uni/M Jaar 1/Sem2/ComS/averages_rel_h2.csv", row.names = FALSE)